V SQUARE DIGITAL INVITATION

Files:
- index.html       Main invitation webpage
- invitation.jpg   The exact invitation image supplied by you

How to test:
1. Keep index.html and invitation.jpg in the same folder.
2. Double-click index.html on a computer, or open it using a local web server.
3. Tap "அழைப்பிதழை திறக்க" to see the flower/petal opening animation.

For WhatsApp:
Upload this folder to a web host (for example GitHub Pages, Netlify, or Vercel) and share the resulting HTTPS link in WhatsApp.
